# FORGE — Deploy to iPhone in 10 Minutes

## What you're getting
A Progressive Web App (PWA) that lives on your iPhone home screen,
launches full-screen with no browser chrome, and works offline.
No App Store. No developer account. Free forever.

---

## STEP 1 — Get a free GitHub account
1. Go to https://github.com
2. Click "Sign up" — takes 2 minutes
3. Verify your email

---

## STEP 2 — Create a new repository
1. Click the "+" icon in the top right → "New repository"
2. Name it exactly:  forge-app
3. Set it to PUBLIC (required for free GitHub Pages)
4. Check "Add a README file"
5. Click "Create repository"

---

## STEP 3 — Upload your files
You need to upload these 4 items:
  - index.html
  - manifest.json
  - service-worker.js
  - icons/  (the whole folder with icon-192.png and icon-512.png)

To upload:
1. In your new repository, click "Add file" → "Upload files"
2. Drag and drop index.html, manifest.json, service-worker.js
3. Click "Commit changes"
4. Then click "Add file" → "Upload files" again
5. Create the icons folder: type "icons/" in the file path box,
   then upload icon-192.png and icon-512.png
6. Commit changes

---

## STEP 4 — Enable GitHub Pages
1. In your repository, click "Settings" (top tab)
2. In the left sidebar, click "Pages"
3. Under "Source", select "Deploy from a branch"
4. Under "Branch", select "main" and "/ (root)"
5. Click "Save"
6. Wait ~60 seconds, then refresh
7. You'll see: "Your site is live at https://YOURUSERNAME.github.io/forge-app/"

---

## STEP 5 — Add to iPhone Home Screen
1. On your iPhone, open Safari (must be Safari, not Chrome)
2. Go to: https://YOURUSERNAME.github.io/forge-app/
3. Tap the Share button (the box with an arrow pointing up)
4. Scroll down and tap "Add to Home Screen"
5. Name it "FORGE" and tap "Add"

Done. FORGE is now on your home screen like a native app.

---

## IMPORTANT NOTES

• Your data is stored locally on your device using the app's
  storage — it does NOT sync to GitHub or any server.
  This means it's private and offline-capable.

• If you clear Safari's website data, you'll lose your logs.
  Use the Export feature regularly to back up your data.

• To update the app in the future:
  Just upload a new index.html to GitHub.
  The app will update the next time you open it with internet.

• The app icon may take a minute to appear correctly after
  adding to home screen — this is normal.

---

## TROUBLESHOOTING

"Site not found" after enabling Pages:
→ Wait 2-3 minutes and hard refresh

App opens in browser instead of full-screen:
→ Make sure you used Safari (not Chrome) to add it
→ Delete and re-add to home screen

Food search not working:
→ This requires internet. The rest of the app works offline.

Icon looks blurry:
→ Clear Safari cache, remove from home screen, re-add

---

Questions? The FORGE app is entirely self-contained in index.html —
all your data lives on your device and can be exported anytime.
